# Streaming Status
> **Using this self-bot, you can get a custom streaming status, hosted 24/7!**

**Note: This is against Discord ToS and can get your account terminated. Although, this self-bot doesn't get detected by Discord. You can get terminated if you get reported.**

__Reselling of the code is not allowed, although, using it for self-purposes is. This is OPEN SOURCE!__

**The self-bot works on [repl.it](https://repl.it/) or [Heroku](https://heroku.com/) and can be hosted 24/7 using [UptimeRobot](https://uptimerobot.com).**

**Add your user token in the `.env` file and replace it with `user_token_here`**

